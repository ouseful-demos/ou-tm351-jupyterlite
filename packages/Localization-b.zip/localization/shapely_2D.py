from . import geometry as gx
from pygeoif.geometry import Point, Polygon

""" 2D shapely polygon models for circles"""

def polygonize(c,d):
    def square_buffer(p, r):
        # Hack a simple square buffer round the point
        xmin, ymin = pc.x - r, pc.y - r
        xmax, ymax = pc.x + r, pc.y + r
        square_points = [(xmin, ymin), (xmin, ymax), (xmax, ymax), (xmax, ymin)]
        # Construct the square polygon
        return Polygon(square_points)

    l = len(c)
    # P = [Point(0, 0).buffer(1.0)] * l
    P = [Point(0, 0)] * l
    for i in range(l):
        pc = c[i]
        r = d[i]
        # P[i]=Point(pc.x, pc.y).buffer(r)
        P[i] = square_buffer(Point(pc.x, pc.y), r)
    return P
