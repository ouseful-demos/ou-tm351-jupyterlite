from . import geometry as gx
from pygeoif.geometry import Point, Polygon

""" 2D shapely polygon models for circles"""

def polygonize(c,d):
	l=len(c)
	P=[Point(0, 0).buffer(1.0)]*l
	for i in range(l):
		pc=c[i]
		r=d[i]
		#P[i]=Point(pc.x, pc.y).buffer(r)
		# Hack a simple square buffer round the point
		xmin, ymin = pc.x - r, pc.y - r
		xmax, ymax = pc.x + r, pc.y + r
		square_points = [(xmin, ymin), (xmin, ymax), (xmax, ymax), (xmax, ymin)]
		# Construct the square polygon
		P[i] = Polygon(square_points)
	return P
